package com.example.android.justjava8;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.text.NumberFormat;

public class MainActivity extends AppCompatActivity {
    int numberOfCoffee =1;
    Button incrementBtn, decrementBtn,orderBtn;
    TextView quantityTextView, priceTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }
    public void submitOrder(View view){
        displayPrice(numberOfCoffee);


    }
    private int display(int number){
         quantityTextView = (TextView)findViewById(R.id.quantity__text_view);
        quantityTextView.setText(""+ number);
        return numberOfCoffee;
    }
    public void displayPrice(int number){
        priceTextView = (TextView)findViewById(R.id.price__text_view);
        priceTextView.setText(NumberFormat.getCurrencyInstance().format(number*5));
    }
    public void incrementCoffee(View view){
        numberOfCoffee++;
        display(numberOfCoffee);
    }
    public void decrementCoffee(View view){
        while (numberOfCoffee>0)
        numberOfCoffee--;
        display(numberOfCoffee);
    }

}
